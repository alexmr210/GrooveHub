COMANDOS INICIAR PROGRAMA PYTHON 

conda deactivate	#la terminal de mi portátil se inicia en un entorno virtual que tengo que desactivar asi para que funcione mi programa Python cada vez que abro una terminal

python3 __init__.py 5433 postgres tfg tfg7	#Si quiero iniciar programa con usuario y contraseña que he usado siempre (usuario postgres contraseña tfg)

python3 __init__.py 5433 usuario1 usuario1 tfg7	#Si quiero iniciar el programa con el otro usuario que cree para insertar con ese otro usuario
